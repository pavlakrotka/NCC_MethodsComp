## ----setup, include=FALSE-----------------------------------------------------
library(knitr)
opts_chunk$set(echo = TRUE,
               message = FALSE,
               error = FALSE,
               warning = FALSE,
               comment = "",
               fig.align = "center",
               out.width = "70%")

## ---- message=FALSE, warning=FALSE, results=FALSE, eval=FALSE-----------------
#  install.packages("NCC")

## ---- message=FALSE, warning=FALSE, results=FALSE, eval=FALSE-----------------
#  # install.packages("devtools")
#  devtools::install_github("pavlakrotka/NCC", build_vignettes = TRUE)

