utils::globalVariables(c("j0", "ind_trend0", "all_trend0", "n"))
